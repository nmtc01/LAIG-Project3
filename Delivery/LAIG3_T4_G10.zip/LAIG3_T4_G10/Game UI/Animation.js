/**
 * Animation
 * @constructor
 * @param scene - Reference to MyScene object
 */
class Animation{
    /**
     * @constructor 
     */
    constructor(){
      
    }
      /**
     * @method update
     * atualizar o seu estado em função do tempo
     * @param {int} t 
     */
    update(t){
    }
    /**
     * @method apply
     * aplicar a transformação sobre a matriz de transformações da cena quando adequado 
     */
    apply(){
    }

}