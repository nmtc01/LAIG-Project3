/**
 * 
 */
class MyGameMove{
    //Stores a game move

    constructor(){
        //Has:
            // Pointer to moved piece (MyPiece)
            // Pointer to origin tile (MyTile)
            // Pointer to destination tile (MyTile)
            // Gameboard state before the move (MyGameboard representation)

        this.type=0; 
    }
    /**
     * Animate piece moving 
     */
    Animate(){

    }
}